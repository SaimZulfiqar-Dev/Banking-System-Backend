const mongoose = require('mongoose');

function connectDB(){
    mongoose.connect(process.env.MONGO_URI)
    .then(()=>{
        console.log("DataBase Connected")
    })
    .catch(err =>{
        // ADDED 'err' HERE TO SEE THE REAL PROBLEM
        console.log("Error connecting to DB:", err.message) 
        process.exit(1);
    })
}

module.exports = connectDB;