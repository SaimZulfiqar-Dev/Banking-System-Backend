const transactionModel = require('../models/transaction.model');
const ledgerModel = require('../models/ledger.model');
const accountModel = require('../models/account.model');
const emailService = require('../services/email.service');
const userModel = require('../models/user.model');
const mongoose = require('mongoose')

/**
 * - Create a new transaction
 * THE 10-STEP TRANSFER FLOW:
 * 1. Validate request
 * 2. Validate idempotency key
 * 3. Check account status
 * 4. Derive sender balance from ledger
 * 5. Create transaction (PENDING)
 * 6. Create DEBIT ledger entry
 * 7. Create CREDIT ledger entry
 * 8. Mark transaction COMPLETED
 * 9. Commit MongoDB session
 * 10. Send email notification
 */

async function createTransaction(req,res){

//1)Validate Request

const {fromAccount, toAccount, amount, idempotencyKey} = req.body;
if(!fromAccount || !toAccount || !amount || !idempotencyKey){
    return res.status(400).json({
        message:"FromAccount , ToAccount , Amount and idempotencyKey are requires"
    })
}

const fromUserAccont = await accountModel.findOne({_id:fromAccount});

const toUserAccount = await accountModel.findOne({_id:toAccount});

if(!fromUserAccont || !toUserAccount){
    return res.status(400).json({
        message:"Invalid fromAccount or toAccount"
    })
}

if (fromUserAccont.user.toString() !== req.user._id.toString()) {
    return res.status(403).json({
        message: "Unauthorized: You can only transfer money from your own account."
    });
}

//2)Validate IdempotencyKey

const isTransactionAlreadyExists = await transactionModel.findOne({
    idempotencyKey:idempotencyKey
})
if(isTransactionAlreadyExists){
    if(isTransactionAlreadyExists.status === "COMPLETED"){
        return res.status(200).json({
            message:"Transaction already Completed"
        })
    }
    if(isTransactionAlreadyExists.status === "PENDING"){
        return res.status(200).json({
            message:"Transaction is Pending, Please wait!!"
        })
    }
    if(isTransactionAlreadyExists.status === "FAILED"){
        return res.status(400).json({
            message:"Transaction Failed, Please Try Again"
        })
    }
    if(isTransactionAlreadyExists.status === "REVERSED"){
        return res.status(500).json({
            message:"Transaction Reversed, Please Retry"
        })
    }
}

//3)Check Account Status

if(fromUserAccont.status !=="ACTIVE" || toUserAccount.status !=="ACTIVE"){
    return res.status(400).json({
        message:"Both FromAccount and ToAccount must be active to process Transaction"
    })
}

//4)Derive sender balance from ledger

const balance = await fromUserAccont.getBalance();

if(balance < amount){
    return res.status(400).json({
        message:`Insufficient Balance. Current Balance ${balance}. Requested amount is ${amount}.`
    })
}

let transaction;
//5)Create transaction (PENDING)
try{
const session = await mongoose.startSession();
session.startTransaction();

 transaction = (await transactionModel.create([{
    fromAccount,
    toAccount,
    amount,
    idempotencyKey,
    status:"PENDING"
}],{session}))[ 0 ];

//6)Create DEBIT ledger entry

const debitLedgerEntry = await ledgerModel.create([{
    account:fromAccount,
    amount:amount,
    transaction:transaction._id,
    type:"DEBIT"
}],{session})

await(()=>{
    return new Promise((resolve)=>setTimeout(resolve,15*1000))
})()

//7)Create CREDIT ledger entry

const creditLedgerEntry = await ledgerModel.create([{
    account:toAccount,
    amount:amount,
    transaction:transaction._id,
    type:"CREDIT"
}],{session})

//8)Mark transaction COMPLETED

await transactionModel.findOneAndUpdate(
    {_id:transaction._id},
    {status:"COMPLETED"},
    {session}
)

//9)Commit MongoDB session

await session.commitTransaction();
session.endSession();

}catch(err){
    return res.status(400).json({
        message:"Transaction is Pending, retry after some time"
    })
}
//10)Send email notification

await emailService.sendTransactionEmail(req.user.email,req.user.name,amount,toAccount);

return res.status(201).json({
    message:"Transaction Completed Successfully!",
    transaction:transaction
})


}

async function createInitialFundsTransaction(req, res) {
    const { toAccount, amount, idempotencyKey } = req.body;

    if (!toAccount || !amount || !idempotencyKey) {
        return res.status(400).json({
            message: "ToAccount, Amount and idempotencyKey are required"
        });
    }

    // 1. USE accountModel HERE
    const toUserAccount = await accountModel.findById(toAccount);

    if (!toUserAccount) {
        return res.status(400).json({
            message: "Invalid toAccount - Account does not exist"
        });
    }

    // 2. USE accountModel HERE TOO
    // This finds the account belonging to the logged-in user
    const fromUserAccount = await accountModel.findOne({
        user: req.user._id
    });

    if (!fromUserAccount) {
        return res.status(400).json({
            message: "System User Account Not Found"
        });
    }

    const session = await mongoose.startSession();
    session.startTransaction();

    // FIX 5: Wrap in try/catch so the transaction aborts if it fails
    try {
        const transaction = new transactionModel({
            fromAccount: fromUserAccount._id,
            toAccount,
            amount,
            idempotencyKey,
            status: "PENDING"
        });

        const debitLedgerEntry = await ledgerModel.create([{
            account: fromUserAccount._id,
            amount: amount,
            transaction: transaction._id,
            type: "DEBIT"
        }], { session });

        const creditLedgerEntry = await ledgerModel.create([{
            account: toAccount, // Or toUserAccount._id depending on your schema
            amount: amount,
            transaction: transaction._id,
            type: "CREDIT"
        }], { session });

        // FIX 4: Changed from function call to property assignment
        transaction.status = "COMPLETED";
        await transaction.save({ session });

        await session.commitTransaction();
        session.endSession();

        return res.status(201).json({
            message: "Initial Funds Transaction Completed Successfully!",
            transaction: transaction
        });

    } catch (error) {
        // If anything fails above, undo the database changes safely
        await session.abortTransaction();
        session.endSession();
        console.error("Transaction Error:", error);
        
        return res.status(500).json({
            message: "Transaction failed",
            error: error.message
        });
    }
}
module.exports = {
    createTransaction,
    createInitialFundsTransaction
}