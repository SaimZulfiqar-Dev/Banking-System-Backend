const {Router} = require('express');
//this method is used instead of but both do the same work
// const express = require('express')
// const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const transactionController = require('../controllers/transaction.controller')

const transactionRoutes = Router();

transactionRoutes.post('/',authMiddleware.authMiddleware,transactionController.createTransaction);

transactionRoutes.post('/system/initial-funds',authMiddleware.authSystemUserMiddleware,transactionController.createInitialFundsTransaction)

module.exports = transactionRoutes;